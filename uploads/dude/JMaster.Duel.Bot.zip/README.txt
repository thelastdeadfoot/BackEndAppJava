If the EXE does not work you may need to install the C++ runtime redistributables first:
https://aka.ms/vs/17/release/vc_redist.x64.exe

More information:
https://docs.microsoft.com/en-US/cpp/windows/latest-supported-vc-redist